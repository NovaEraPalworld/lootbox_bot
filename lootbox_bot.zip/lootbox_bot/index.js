
require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection, SlashCommandBuilder, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

const TICKET_INTERVAL = 5 * 60 * 60 * 1000; // 5 horas
const inventoryPath = './data/inventory.json';

function saveInventory() {
  fs.writeFileSync(inventoryPath, JSON.stringify(inventory, null, 2));
}

let inventory = {};
if (fs.existsSync(inventoryPath)) {
  inventory = JSON.parse(fs.readFileSync(inventoryPath));
}


client.once('ready', async () => {
  // Atualização de tempo em call a cada minuto
  setInterval(() => {
    const now = Date.now();
    for (const userId in inventory) {
      const user = inventory[userId];
      if (user.joinedAt) {
        const delta = now - user.joinedAt;
        user.dailyTime += delta;
        user.voiceAccumulated += delta;
        user.joinedAt = now;

        while (user.voiceAccumulated >= TICKET_INTERVAL) {
          user.voiceAccumulated -= TICKET_INTERVAL;
          user.tickets += 1;
        }
      }
    }
    saveInventory();
  }, 60 * 1000);

  console.log(`Bot logado como ${client.user.tag}`);

  // Reset diário
  setInterval(() => {
    const now = new Date();
    if (now.getHours() === 0 && now.getMinutes() === 0) {
      for (const userId in inventory) {
        inventory[userId].dailyTime = 0;
        inventory[userId].dailyTickets = 0;
      }
      saveInventory();
    }
  }, 60 * 1000);

  // Registra comando /ticketcall
  const ticketCallCommand = new SlashCommandBuilder()
    .setName('ticketcall')
    .setDescription('Veja quanto tempo falta para ganhar um ticket por call');
  await client.application.commands.create(ticketCallCommand);
});

client.on('voiceStateUpdate', (oldState, newState) => {
  const userId = newState.id;
  const now = Date.now();

  if (!inventory[userId]) {
    inventory[userId] = {
      tickets: 0,
      items: [],
      joinedAt: null,
      dailyTime: 0,
      dailyTickets: 0,
      voiceAccumulated: 0
    };
  }

  const userInv = inventory[userId];

  if (!oldState.channelId && newState.channelId) {
    userInv.joinedAt = now;
  } else if (oldState.channelId && !newState.channelId && userInv.joinedAt) {
    const timeSpent = now - userInv.joinedAt;
    userInv.dailyTime += timeSpent;
    userInv.voiceAccumulated += timeSpent;
    userInv.joinedAt = null;

    while (userInv.voiceAccumulated >= TICKET_INTERVAL) {
      userInv.voiceAccumulated -= TICKET_INTERVAL;
      userInv.tickets += 1;
    }

    saveInventory();
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  try {
    const { commandName } = interaction;

    if (commandName === 'ticketcall') {
      const userId = interaction.user.id;
      const userInv = inventory[userId] || {};
      const spent = userInv.voiceAccumulated || 0;
      const remaining = TICKET_INTERVAL - spent;

      const hours = Math.floor(remaining / 3600000);
      const minutes = Math.floor((remaining % 3600000) / 60000);
      const seconds = Math.floor((remaining % 60000) / 1000);

      await interaction.reply(`⏳ Tempo restante para próximo ticket: **${hours}h ${minutes}m ${seconds}s**`);
    }

    else if (commandName === 'lootbox') {
      const userId = interaction.user.id;

      if (!inventory[userId]) {
        inventory[userId] = { tickets: 0, items: [] };
        saveInventory();
      }

      if (inventory[userId].tickets <= 0) {
        await interaction.reply({
          content: '🎫 Você não tem tickets suficientes para abrir uma lootbox!',
          ephemeral: true
        });
        return;
      }

      inventory[userId].tickets -= 1;
      saveInventory();

      const lootbox = JSON.parse(fs.readFileSync('./data/lootbox.json', 'utf-8'));
      const shuffled = [...lootbox].sort(() => 0.5 - Math.random());
      const finalItem = shuffled[Math.floor(Math.random() * shuffled.length)];

      let displayNames = [];
      for (let i = 0; i < 10; i++) {
        const randomItem = lootbox[Math.floor(Math.random() * lootbox.length)];
        displayNames.push(randomItem.name);
      }
      displayNames.push(finalItem.name);

      await interaction.reply('🎁 Abrindo lootbox...');

      for (const name of displayNames) {
        await new Promise(res => setTimeout(res, 500));
        await interaction.editReply(`🎁 Sorteando: **${name}**`);
      }

      await new Promise(res => setTimeout(res, 500));
      await interaction.editReply({
        content: `🎉 Você ganhou **${finalItem.name}**!`,
        embeds: [{
          title: finalItem.name,
          image: { url: finalItem.image },
          color: 0xFFD700
        }]
      });

      inventory[userId].items.push(finalItem.name);
      saveInventory();
    }

    else if (commandName === 'inventario') {
      const userId = interaction.user.id;
      if (!inventory[userId]) {
        inventory[userId] = { tickets: 0, items: [] };
        saveInventory();
      }

      const userInventory = inventory[userId];
      const lootbox = JSON.parse(fs.readFileSync('./data/lootbox.json', 'utf-8'));

      const embeds = [];

      if (userInventory.items.length > 0) {
        for (const itemName of userInventory.items) {
          const item = lootbox.find(i => i.name === itemName);
          if (item) {
            embeds.push({
              title: `📦 ${item.name}`,
              description: `Item do inventário de <@${userId}>`,
              color: 0x00AE86,
              thumbnail: { url: item.image }
            });
          }
        }
      }

      const ticketsEmbed = {
        title: `🎒 Inventário de ${interaction.user.username}`,
        fields: [
          { name: '🎫 Tickets', value: `${userInventory.tickets}`, inline: true },
          {
            name: '📦 Itens',
            value: userInventory.items.length > 0
              ? `${userInventory.items.length} item(s)`
              : 'Inventário limpo'
          }
        ],
        color: 0x00AE86
      };

      await interaction.reply({
        embeds: [ticketsEmbed, ...embeds]
      });
    }

    
    else if (commandName === 'remover') {
      if (!interaction.member.permissions.has('Administrator')) {
        await interaction.reply({ content: 'Você não tem permissão para usar esse comando.', ephemeral: true });
        return;
      }

      const targetUser = interaction.options.getUser('usuario');
      const itemName = interaction.options.getString('item');

      if (!inventory[targetUser.id] || !inventory[targetUser.id].items) {
        await interaction.reply({ content: 'Este usuário não tem inventário.', ephemeral: true });
        return;
      }

      const index = inventory[targetUser.id].items.findIndex(i => i.toLowerCase() === itemName.toLowerCase());

      if (index === -1) {
        await interaction.reply({ content: `O item "${itemName}" não foi encontrado no inventário de ${targetUser.username}.`, ephemeral: true });
        return;
      }

      inventory[targetUser.id].items.splice(index, 1);
      saveInventory();

      await interaction.reply({ content: `Item "${itemName}" removido do inventário de ${targetUser.username}.` });
    }


    else if (commandName === 'darticket') {
      if (!interaction.member.permissions.has('Administrator')) {
        await interaction.reply({ content: 'Você não tem permissão para usar esse comando.', ephemeral: true });
        return;
      }

      const targetUser = interaction.options.getUser('usuario');
      const quantidade = interaction.options.getInteger('quantidade');

      if (!inventory[targetUser.id]) {
        inventory[targetUser.id] = { tickets: 0, items: [] };
      }

      inventory[targetUser.id].tickets += quantidade;
      saveInventory();

      await interaction.reply(`🎫 ${quantidade} ticket(s) foram dados para ${targetUser.username}.`);
    }

  } catch (err) {
    console.error("Erro ao executar comando:", err);
    if (interaction.replied || interaction.deferred) {
      interaction.editReply({ content: '❌ Ocorreu um erro ao executar este comando.' });
    } else {
      interaction.reply({ content: '❌ Ocorreu um erro ao executar este comando.', ephemeral: true });
    }
  }
});

client.login(process.env.TOKEN);
